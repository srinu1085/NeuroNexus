// JavaScript for quiz functionality
const quizForm = document.getElementById("quiz-form");
const quizTakeForm = document.getElementById("quiz-take-form");
const addQuestionButton = document.getElementById("add-question");
const createQuizButton = document.getElementById("create-quiz");
const startQuizButton = document.getElementById("start-quiz");
const submitQuizButton = document.getElementById("submit-quiz");
const quizQuestions = document.getElementById("quiz-questions");
const quizResults = document.getElementById("quiz-results");

let quizData = [];

addQuestionButton.addEventListener("click", addQuestion);
createQuizButton.addEventListener("click", createQuiz);
startQuizButton.addEventListener("click", startQuiz);
submitQuizButton.addEventListener("click", submitQuiz);

function addQuestion() {
    const questionInput = document.getElementById("question");
    const choicesInput = document.getElementById("choices");
    const correctAnswerInput = document.getElementById("correct-answer");

    const question = questionInput.value;
    const choices = choicesInput.value.split(",");
    const correctAnswer = correctAnswerInput.value;

    quizData.push({ question, choices, correctAnswer });

    questionInput.value = "";
    choicesInput.value = "";
    correctAnswerInput.value = "";
}

function createQuiz() {
    quizForm.style.display = "none";
    startQuizButton.style.display = "block";
}

function startQuiz() {
    quizTakeForm.style.display = "block";
    startQuizButton.style.display = "none";

    // Dynamically generate quiz questions
    quizData.forEach((question, index) => {
        const questionDiv = document.createElement("div");
        questionDiv.innerHTML = `<p>${index + 1}. ${question.question}</p>`;
        question.choices.forEach((choice) => {
            questionDiv.innerHTML += `<input type="radio" name="q${index}" value="${choice}"> ${choice}<br>`;
        });
        quizQuestions.appendChild(questionDiv);
    });
}

function submitQuiz() {
    const answers = [];
    quizData.forEach((question, index) => {
        const selectedChoice = document.querySelector(`input[name="q${index}"]:checked`);
        if (selectedChoice) {
            answers.push(selectedChoice.value);
        }
    });

    // Calculate the score
    let score = 0;
    answers.forEach((answer, index) => {
        if (answer === quizData[index].correctAnswer) {
            score++;
        }
    });

    // Display the results
    quizResults.innerHTML = `<p>Your Score: ${score} out of ${quizData.length}</p>`;
}
